/**
 * Exercise: Creating variables
 */

 /**
 * Question 1:
 * Store your first name in variable called "name"
 */

/**
 * Question 2:
 * We need to track the number of hits on button one. Create a variable called "buttonOneHits" with a starting numerical value of 0 (zero)
 */

 /**
 * Question 3:
 * Create a boolean called "isItDark" with a starting value of false
 */

 /**
 * Question 4:
 * Create an array called coding. The array should have these values: "HTML", "CSS", "jQuery", "Front-End"
 */


 /**
 * Exercise: Selecting and Manipulating!
 */

/**
 * Question 1:
 * When button 1 is clicked, change the text in the header's h1 tag to read your name
 * Bonus: Use your previously created variable called "name"
 */


/**
 * Question 2:
 * When button 1 is clicked, select all paragraphs on the page and change the color to blue and font to Georgia.
 * Try to do this with only one jQuery call. $('selector').css({'property': 'value', 'property': 'value'});
 */

/**
 * Question 3:
 * When button 1 is clicked, change the html content of all "blockquotes" to be "<span>no quote</span>"
 */

/**
 * Question 4:
 * When button 1 is clicked, select all <h2> elements on this page, and change the text to say "jQuery Ninja".
 */

/**
 * Question 5:
 * When button 1 is clicked, change the src of the image with class "city" to be "http://lorempixel.com/g/500/400/food"
 */

/**
 * Question 6:
 * When button 1 is clicked, increment your previously created variable "buttonOneHits" by 1. 
 * Bonus: Log your new value in the console.
 */

/**
 * Exercise: Appending Content
 */

/**
 * Question 1:
 * When button 2 is clicked, Add 2 list items to the <ol> (Fact Five and Fact Six)
 */

/**
 * Question 2:
 * When button 2 is clicked, Add another paragraph BEFORE the paragraph in the last section. It should say: "This paragraph should come first. I'll add content later, this is a placeholder."
 */

/**
 * Exercise: Effects and Animations
 */

/**
 * Question 1:
 * When button 2 is clicked, Fade in the hidden footer.
 */

/**
 * Question 2:
 * When button 2 is clicked, Animate the size of the image to be width: 100% and opacity: 1
 */

 /**
 * Exercise: Conditionals
 */

/**
 * Question 1:
 * When button 3 is clicked, get the text in the <h1> and store it in a variable called "headingText". Write an if statement that checks if the headingText is equal to your previously created variable called "name". If it is, change the background color of the page to this hex value "#ccc". If it's not change the background color to "#000";
 */

/**
 * Question 2:
 * When button 3 is clicked, check if the previously created variable "buttonOneHits" is greater than 1. If it is then change change the oapcity of the button to ".3". If it's greater than 3, then change the opacity to ".5". If none of those are true change the opacity to ".8".
 */

 /**
 * Question 3:
 * When button 3 is clicked, check if the previously created variable "buttonOneHits" is greater than 1 AND your previoiusly created variable "headingText" is equal to your name. If this is true, change the color of the <h1> to green.
 */

 /**
 * Exercise: For loops
 */

 /**
 * Question 1:
 * Create a for loop to console.log a number from 0 to 10
 */

/**
 * Question 2:
 * Create a for loop to console.log each one of the values in your previously created array called "codiing"
 */

 /**
 * Question 3:
 * Create a for loop to add each one of the values in your previously created array called "codiing" to the <ol> list on the page. (When you're done, there should now be 9 items in the list)
 */

 /**
 * Exercise: Getting data from forms
 */

  /**
 * Question 1:
 * On submitting the form in the footer, create a variable called "usersEmail" and save the value from the input field. Don't forget to prevent the default form submission by using "event.preventDefault"
 */

  /**
 * Question 2:
 * On submitting the form in the footer, alert "You email is {usersEmail}". You should replace {usersEmail} with the email of the user. Tip: You need to concatenate this string using plus signs.
 */

 /**
 * Question 3:
 * On submitting the form in the footer, change the background color of the footer to green.
 */
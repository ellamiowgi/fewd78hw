document.getElementbyId('signUp').onclick = function () {
	window.alert('Not taking signups at this time');
}